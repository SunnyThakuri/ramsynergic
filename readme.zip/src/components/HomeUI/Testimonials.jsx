// import Slider from "react-slick"
// import userImg1 from "../../assets/HomeUI/successUser.png"
// import userImg2 from "../../assets/HomeUI/successUser2.jpg"
// import userImg2 from "../../assets/HomeUI/successUser3.jpg"


// const Testimonials = () => {
//   return (
//     <>
//       <div className="font-Poppins mx-[166.5px]">
//         <div className="left_text">
//           <h1 className="text-[32px] text-[#2C2C2C] font-semibold">What our clients
//             says about us</h1>
//           <p className="text-[#828282]">Client Testimonials: Smooth Relocations Through Our Expertise</p>
//         </div>


//         <Slider>



//           <div className="slider001">

//           </div>
//         </Slider>
//       </div>
//     </>
//   )
// }
// export default Testimonials

const Testimonials = () => {
  return (
    <div>Testimonials</div>
  )
}
export default Testimonials